# -*- coding: utf-8 -*-

f = open ('mapdata.js','r+');
names = []

count = 0
for line in f.readlines():
    start = line.find('url: "./htmls/') 
    if( start != -1 ):
        print line[start+14:-8] 
        names.append( line[start+14:-8])
        f = open('./htmls/'+line[start+14:-3], 'w')
        f.close()
        count += 1
for name in names:
    try:    
        f = open('./htmls/'+name+".html", 'w')
        f.write("<img src=\"../images/" + name + ".png\"  height=\"600\" width=\"1200\">")
    except:
        print name    
    f.close()
        


print count 
f.close()

