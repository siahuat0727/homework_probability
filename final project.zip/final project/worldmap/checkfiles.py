from os import listdir
from os.path import isfile, join

htmlpath = "./htmls"
imgpath = "./images"
count = 0
htmlfiles = [f for f in listdir(htmlpath) if isfile(join(htmlpath, f))]

imgfiles = [f for f in listdir(imgpath) if isfile(join(imgpath, f))]

for i in range(len(imgfiles)):
    imgfiles[i] = imgfiles[i][:-4]

for i in range(len(htmlfiles)):
    htmlfiles[i] = htmlfiles[i][:-5]



for f in htmlfiles:
    if(not(f in imgfiles) ):
        print f
        count += 1 

print count 
count = 0
'''
for f in imgfiles:
    if(not(f in htmlfiles) ):
        print f
        count += 1 
print count 
'''
