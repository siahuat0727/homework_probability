var simplemaps_worldmap_mapdata = {

	main_settings:{
		//General settings
		width: '700', //or 'responsive'
		background_color: '#FFFFFF',	
		background_transparent: 'yes',
		border_color: '#ffffff',
		popups: 'detect', //on_click, on_hover, or detect
	
		//State defaults
		state_description:   'State description',
		state_color: '#88A4BC',
		state_hover_color: '#3B729F',
		state_url: 'http://simplemaps.com',
		border_size: 1.5,		
		all_states_inactive: 'no',
		all_states_zoomable: 'no',		
		
		//Location defaults
		location_description:  'Location description',
		location_color: '#FF0067',
		location_opacity: .8,
		location_hover_opacity: 1,
		location_url: '',
		location_size: 25,
		location_type: 'square', // circle, square, image
		location_image_source: 'frog.png', //name of image in the map_images folder		
		location_border_color: '#FFFFFF',
		location_border: 2,
		location_hover_border: 2.5,				
		all_locations_inactive: 'no',
		all_locations_hidden: 'no',
		
		//Labels
		label_color: '#d5ddec',	
		label_hover_color: '#d5ddec',		
		label_size: 22,
		label_font: 'Arial',
		hide_labels: 'no',
		
		//Zoom settings
		zoom: 'yes', //use default regions
		back_image: 'no', //Use image instead of arrow for back zoom				
		initial_back: 'no', //Show back button when zoomed out and do this JavaScript upon click		
		initial_zoom: -1,  //-1 is zoomed out, 0 is for the first continent etc	
		initial_zoom_solo: 'no', //hide adjacent states when starting map zoomed in
		region_opacity: 1,
		region_hover_opacity: .6,
		zoom_out_incrementally: 'yes',  // if no, map will zoom all the way out on click
		zoom_percentage: .99,
		zoom_time: .5, //time to zoom between regions in seconds
		
		//Popup settings
		popup_color: 'white',
		popup_opacity: .9,
		popup_shadow: 1,
		popup_corners: 5,
		popup_font: '12px/1.5 Verdana, Arial, Helvetica, sans-serif',
		popup_nocss: 'no', //use your own css	
		
		//Advanced settings
		div: 'map',
		auto_load: 'yes',		
		url_new_tab: 'yes', 
		images_directory: 'default', //e.g. 'map_images/'
		fade_time:  .1, //time to fade out		
		link_text: 'View Website'  //Text mobile browsers will see for links	
	},

	
	state_specific: {
		"AF":{
			name: "Afghanistan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Afghanistan.html"
		},
		"AO":{
			name: "Angola",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Angola.html"
		},
		"AL":{
			name: "Albania",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Albania.html"
		},
		"AE":{
			name: "United Arab Emirates",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/United Arab Emirates.html"
		},
		"AR":{
			name: "Argentina",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Argentina.html"
		},
		"AM":{
			name: "Armenia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Armenia.html"
		},
		"AU":{
			name: "Australia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Australia.html"
		},
		"AT":{
			name: "Austria",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Austria.html"
		},
		"AZ":{
			name: "Azerbaijan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Azerbaijan.html"
		},
		"BI":{
			name: "Burundi",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Burundi.html"
		},
		"BE":{
			name: "Belgium",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Belgium.html"
		},
		"BJ":{
			name: "Benin",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Benin.html"
		},
		"BF":{
			name: "Burkina Faso",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Burkina Faso.html"
		},
		"BD":{
			name: "Bangladesh",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Bangladesh.html"
		},
		"BG":{
			name: "Bulgaria",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Bulgaria.html"
		},
		"BH":{
			name: "Bahrain",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Bahrain.html"
		},    
		"BA":{
			name: "Bosnia and Herzegovina",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Bosnia and Herzegovina.html"
		},
		"BY":{
			name: "Belarus",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Belarus.html"
		},
		"BZ":{
			name: "Belize",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Belize.html"
		},
		"BO":{
			name: "Bolivia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Bolivia.html"
		},
		"BR":{
			name: "Brazil",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Brazil.html"
		},
		"BN":{
			name: "Brunei Darussalam",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Brunei Darussalam.html"
		},
		"BT":{
			name: "Bhutan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Bhutan.html"
		},
		"BW":{
			name: "Botswana",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Botswana.html"
		},
		"CF":{
			name: "Central African Republic",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Central African Republic.html"
		},
		"CA":{
			name: "Canada",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Canada.html"
		},
		"CH":{
			name: "Switzerland",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Switzerland.html"
		},
		"CL":{
			name: "Chile",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Chile.html"
		},
		"CN":{
			name: "China",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/China.html"
		},
		"CI":{
			name: "Côte d'Ivoire",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Côte d'Ivoire.html"
		},
		"CM":{
			name: "Cameroon",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Cameroon.html"
		},
		"CD":{
			name: "Democratic Republic of the Congo",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Democratic Republic of the Congo.html"
		},
		"CG":{
			name: "Republic of Congo",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Republic of Congo.html"
		},
		"CO":{
			name: "Colombia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Colombia.html"
		},
		"CR":{
			name: "Costa Rica",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Costa Rica.html"
		},
		"CU":{
			name: "Cuba",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Cuba.html"
		},
		"CZ":{
			name: "Czech Republic",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Czech Republic.html"
		},
		"DE":{
			name: "Germany",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Germany.html"
		},
		"DJ":{
			name: "Djibouti",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Djibouti.html"
		},
		"DK":{
			name: "Denmark",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Denmark.html"
		},
		"DO":{
			name: "Dominican Republic",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Dominican Republic.html"
		},
		"DZ":{
			name: "Algeria",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Algeria.html"
		},
		"EC":{
			name: "Ecuador",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Ecuador.html"
		},
		"EG":{
			name: "Egypt",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Egypt.html"
		},
		"ER":{
			name: "Eritrea",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Eritrea.html"
		},
		"EE":{
			name: "Estonia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Estonia.html"
		},
		"ET":{
			name: "Ethiopia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Ethiopia.html"
		},
		"FI":{
			name: "Finland",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Finland.html"
		},
		"FJ":{
			name: "Fiji",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Fiji.html"
		},
		"GA":{
			name: "Gabon",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Gabon.html"
		},
		"GB":{
			name: "United Kingdom",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/United Kingdom.html"
		},
		"GE":{
			name: "Georgia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Georgia.html"
		},
		"GH":{
			name: "Ghana",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Ghana.html"
		},
		"GN":{
			name: "Guinea",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Guinea.html"
		},
		"GM":{
			name: "The Gambia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/The Gambia.html"
		},
		"GW":{
			name: "Guinea-Bissau",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Guinea-Bissau.html"
		},
		"GQ":{
			name: "Equatorial Guinea",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Equatorial Guinea.html"
		},
		"GR":{
			name: "Greece",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Greece.html"
		},
		"GL":{
			name: "Greenland",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Greenland.html"
		},
		"GT":{
			name: "Guatemala",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Guatemala.html"
		},
		"GY":{
			name: "Guyana",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Guyana.html"
		},
		"HN":{
			name: "Honduras",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Honduras.html"
		},
		"HR":{
			name: "Croatia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Croatia.html"
		},
		"HT":{
			name: "Haiti",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Haiti.html"
		},
		"HU":{
			name: "Hungary",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Hungary.html"
		},
		"ID":{
			name: "Indonesia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Indonesia.html"
		},
		"IN":{
			name: "India",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/India.html"
		},
		"IE":{
			name: "Ireland",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Ireland.html"
		},
		"IR":{
			name: "Iran",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Iran.html"
		},
		"IQ":{
			name: "Iraq",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Iraq.html"
		},
		"IS":{
			name: "Iceland",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Iceland.html"
		},
		"IL":{
			name: "Israel",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Israel.html"
		},
		"IT":{
			name: "Italy",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Italy.html"
		},
		"JM":{
			name: "Jamaica",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Jamaica.html"
		},
		"JO":{
			name: "Jordan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Jordan.html"
		},
		"JP":{
			name: "Japan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Japan.html"
		},
		"KZ":{
			name: "Kazakhstan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Kazakhstan.html"
		},
		"KE":{
			name: "Kenya",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Kenya.html"
		},
		"KG":{
			name: "Kyrgyzstan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Kyrgyzstan.html"
		},
		"KH":{
			name: "Cambodia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Cambodia.html"
		},
		"KR":{
			name: "Republic of Korea",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Republic of Korea.html"
		},
		"XK":{
			name: "Kosovo",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Kosovo.html"
		},
		"KW":{
			name: "Kuwait",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Kuwait.html"
		},
		"LA":{
			name: "Lao PDR",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Lao PDR.html"
		},
		"LB":{
			name: "Lebanon",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Lebanon.html"
		},
		"LR":{
			name: "Liberia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Liberia.html"
		},
		"LY":{
			name: "Libya",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Libya.html"
		},
		"LK":{
			name: "Sri Lanka",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Sri Lanka.html"
		},
		"LS":{
			name: "Lesotho",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Lesotho.html"
		},
		"LT":{
			name: "Lithuania",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Lithuania.html"
		},
		"LU":{
			name: "Luxembourg",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Luxembourg.html"
		},
		"LV":{
			name: "Latvia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Latvia.html"
		},
		"MA":{
			name: "Morocco",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Morocco.html"
		},
		"MD":{
			name: "Moldova",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Moldova.html"
		},
		"MG":{
			name: "Madagascar",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Madagascar.html"
		},
		"MX":{
			name: "Mexico",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Mexico.html"
		},
		"MK":{
			name: "Macedonia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Macedonia.html"
		},
		"ML":{
			name: "Mali",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Mali.html"
		},
		"MM":{
			name: "Myanmar",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Myanmar.html"
		},
		"ME":{
			name: "Montenegro",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Montenegro.html"
		},
		"MN":{
			name: "Mongolia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Mongolia.html"
		},
		"MZ":{
			name: "Mozambique",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Mozambique.html"
		},
		"MR":{
			name: "Mauritania",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Mauritania.html"
		},
		"MW":{
			name: "Malawi",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Malawi.html"
		},
		"MY":{
			name: "Malaysia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Malaysia.html"
		},
		"NA":{
			name: "Namibia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Namibia.html"
		},
		"NE":{
			name: "Niger",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Niger.html"
		},
		"NG":{
			name: "Nigeria",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Nigeria.html"
		},
		"NI":{
			name: "Nicaragua",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Nicaragua.html"
		},
		"NL":{
			name: "Netherlands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Netherlands.html"
		},
		"NO":{
			name: "Norway",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Norway.html"
		},
		"NP":{
			name: "Nepal",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Nepal.html"
		},
		"NZ":{
			name: "New Zealand",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/New Zealand.html"
		},
		"OM":{
			name: "Oman",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Oman.html"
		},
		"PK":{
			name: "Pakistan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Pakistan.html"
		},
		"PA":{
			name: "Panama",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Panama.html"
		},
		"PE":{
			name: "Peru",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Peru.html"
		},
		"PH":{
			name: "Philippines",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Philippines.html"
		},
		"PG":{
			name: "Papua New Guinea",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Papua New Guinea.html"
		},
		"PL":{
			name: "Poland",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Poland.html"
		},
		"KP":{
			name: "Dem. Rep. Korea",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Dem. Rep. Korea.html"
		},
		"PT":{
			name: "Portugal",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Portugal.html"
		},
		"PY":{
			name: "Paraguay",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Paraguay.html"
		},
		"PS":{
			name: "Palestine",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Palestine.html"
		},
		"QA":{
			name: "Qatar",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Qatar.html"
		},
		"RO":{
			name: "Romania",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Romania.html"
		},
		"RU":{
			name: "Russia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Russia.html"
		},
		"RW":{
			name: "Rwanda",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Rwanda.html"
		},
		"EH":{
			name: "Western Sahara",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Western Sahara.html"
		},
		"SA":{
			name: "Saudi Arabia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Saudi Arabia.html"
		},
		"SD":{
			name: "Sudan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Sudan.html"
		},
		"SS":{
			name: "South Sudan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Sudan.html"
		},
		"SN":{
			name: "Senegal",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Senegal.html"
		},
		"SL":{
			name: "Sierra Leone",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Sierra Leone.html"
		},
		"SV":{
			name: "El Salvador",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/El Salvador.html"
		},
		"RS":{
			name: "Serbia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Serbia.html"
		},
		"SR":{
			name: "Suriname",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Suriname.html"
        },
		"SK":{
			name: "Slovakia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Slovakia.html"
		},
		"SI":{
			name: "Slovenia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Slovenia.html"
		},
		"SE":{
			name: "Sweden",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Sweden.html"
		},
		"SZ":{
			name: "Swaziland",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Swaziland.html"
		},
		"SY":{
			name: "Syria",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Syria.html"
		},
		"TD":{
			name: "Chad",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Chad.html"
		},
		"TG":{
			name: "Togo",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Togo.html"
		},
		"TH":{
			name: "Thailand",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Thailand.html"
		},
		"TJ":{
			name: "Tajikistan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Tajikistan.html"
		},
		"TM":{
			name: "Turkmenistan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Turkmenistan.html"
		},
		"TL":{
			name: "Timor-Leste",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Timor-Leste.html"
		},
		"TN":{
			name: "Tunisia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Tunisia.html"
		},
		"TR":{
			name: "Turkey",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Turkey.html"
		},
		"TW":{
			name: "Taiwan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Taiwan.html"
		},
		"TZ":{
			name: "Tanzania",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Tanzania.html"
		},
		"UG":{
			name: "Uganda",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Uganda.html"
		},
		"UA":{
			name: "Ukraine",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Ukraine.html"
		},
		"UY":{
			name: "Uruguay",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Uruguay.html"
		},
		"US":{
			name: "United States",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/United States.html"
		},
		"UZ":{
			name: "Uzbekistan",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Uzbekistan.html"
		},
		"VE":{
			name: "Venezuela",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Venezuela.html"
		},
		"VN":{
			name: "Vietnam",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Vietnam.html"
		},
		"VU":{
			name: "Vanuatu",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Vanuatu.html"
		},
		"YE":{
			name: "Yemen",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Yemen.html"
		},
		"ZA":{
			name: "South Africa",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/South Africa.html"
		},
		"ZM":{
			name: "Zambia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Zambia.html"
		},
		"ZW":{
			name: "Zimbabwe",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Zimbabwe.html"
		},
		"SO":{
			name: "Somalia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Somalia.html"
		},
		"GF":{
			name: "France",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/France.html"
		},
		"FR":{
			name: "France",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/France.html"
		},
		"ES":{
			name: "Spain",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Spain.html"
		},
		"AW":{
			name: "Aruba",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Aruba.html"
		},
		"AI":{
			name: "Anguilla",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Anguilla.html"
		},
		"AD":{
			name: "Andorra",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Andorra.html"
		},
		"AG":{
			name: "Antigua and Barbuda",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Antigua and Barbuda.html"
		},
		"BS":{
			name: "Bahamas",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Bahamas.html"
		},
		"BM":{
			name: "Bermuda",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Bermuda.html"
		},
		"BB":{
			name: "Barbados",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Barbados.html"
		},
		"KM":{
			name: "Comoros",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Comoros.html"
		},
		"CV":{
			name: "Cape Verde",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Cape Verde.html"
		},
		"KY":{
			name: "Cayman Islands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Cayman Islands.html"
		},
		"DM":{
			name: "Dominica",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Dominica.html"
		},
		"FK":{
			name: "Falkland Islands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Falkland Islands.html"
		},
		"FO":{
			name: "Faeroe Islands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Faeroe Islands.html"
		},
		"GD":{
			name: "Grenada",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Grenada.html"
		},
		"HK":{
			name: "Hong Kong",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Hong Kong.html"
		},
		"KN":{
			name: "Saint Kitts and Nevis",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Saint Kitts and Nevis.html"
		},
		"LC":{
			name: "Saint Lucia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Saint Lucia.html"
		},
		"LI":{
			name: "Liechtenstein",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Liechtenstein.html"
		},
		"MF":{
			name: "Saint Martin (French)",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Saint Martin (French).html"
		},
		"MV":{
			name: "Maldives",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Maldives.html"
		},
		"MT":{
			name: "Malta",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Malta.html"
		},
		"MS":{
			name: "Montserrat",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Montserrat.html"
		},
		"MU":{
			name: "Mauritius",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Mauritius.html"
		},
		"NC":{
			name: "New Caledonia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/New Caledonia.html"
		},
		"NR":{
			name: "Nauru",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Nauru.html"
		},
		"PN":{
			name: "Pitcairn Islands",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Pitcairn Islands.html"
		},
		"PR":{
			name: "Puerto Rico",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Puerto Rico.html"
		},
		"PF":{
			name: "French Polynesia",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/French Polynesia.html"
		},
		"SG":{
			name: "Singapore",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Singapore.html"
		},
		"SB":{
			name: "Solomon Islands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Solomon Islands.html"
		},
		"ST":{
			name: "São Tomé and Principe",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/São Tomé and Principe.html"
		},
		"SX":{
			name: "Saint Martin (Dutch)",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Saint Martin (Dutch).html"
		},
		"SC":{
			name: "Seychelles",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Seychelles.html"
		},
		"TC":{
			name: "Turks and Caicos Islands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Turks and Caicos Islands.html"
		},
		"TO":{
			name: "Tonga",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Tonga.html"
		},
		"TT":{
			name: "Trinidad and Tobago",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Trinidad and Tobago.html"
		},
		"VC":{
			name: "Saint Vincent and the Grenadines",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Saint Vincent and the Grenadines.html"
		},
		"VG":{
			name: "British Virgin Islands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/British Virgin Islands.html"
		},
		"VI":{
			name: "United States Virgin Islands",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/United States Virgin Islands.html"
		},
		"CY":{
			name: "Cyprus",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Cyprus.html"
		},
		"RE":{
			name: "Reunion (France)",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Reunion.html"
		},
		"YT":{
			name: "Mayotte (France)",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Mayotte.html"
		},
		"MQ":{
			name: "Martinique (France)",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Martinique.html"
		},
		"GP":{
			name: "Guadeloupe (France)",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Guadeloupe.html"
		},
		"CW":{
			name: "Curaco (Netherlands)",
			description: "default",
			color: "default",
			hover_color: "default",
			url: "./htmls/Curaco.html"
		},
		"IC":{
			name: "Canary Islands (Spain)",
			description: "default",
			color: "#000000",
			hover_color: "default",
			url: "./htmls/Canary Islands.html"
		}
	},
	
	
	locations:{ 
		paris: { 
			name: 'Paris',
			lat: '48.866666670',
			lng: '2.333333333',
			color: 'default',
			description: 'default',
			url: 'default'
		}
	}

}	//end of simplemaps_worldmap_mapdata


