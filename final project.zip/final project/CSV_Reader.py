# -*- coding: utf-8 -*-

import numpy as np
import csv
import matplotlib.pyplot as plt  
from os import listdir
from os.path import isfile, join

htmlpath = "./worldmap/htmls"
htmlfiles = [f for f in listdir(htmlpath) if isfile(join(htmlpath, f))]
for i in range(len(htmlfiles)):
    htmlfiles[i] = htmlfiles[i][:-5]

htmlfiles = sorted(htmlfiles)

w, h = 1201,240;
Matrix = [[0 for x in range(w)] for y in range(h)] 

CountryCount = 0
TempCount    = 0
TemperatureAxis = []

for i in range(1913,2013,2):
    TemperatureAxis.append(i)

ExceptList = ['Antarctica', 'French Southern And Antarctic Lands','Heard Island And Mcdonald Islands']

prev = 'Åland'
Matrix[0][0] = 'Åland'
 
f = open('GlobalLandTemperaturesByCountry.csv', 'r')

#Store the data into list ,from 1913 to 2012
for row in csv.DictReader(f):
    if( row['Country'] != prev ):
        if( TempCount == 1200):
            CountryCount += 1    
            Matrix[CountryCount][0] = row['Country']
        TempCount = 0
        
    prev = row['Country']
    

    date = int(row['dt'][0:4]) 
    if( date>1912 and  date < 2013 and (row['Country'] != ExceptList[0] and row['Country'] != ExceptList[1]  and row['Country'] != ExceptList[2])):
        
        try:
            AverageTemperature = float(row['AverageTemperature'])
        except ValueError:
            AverageTemperature = Matrix[CountryCount][TempCount]
        Matrix[CountryCount][TempCount+1] = AverageTemperature

        TempCount += 1



diff = []



x = np.array(TemperatureAxis)

for i in range(CountryCount):
    mean = []
    for j in range(50):
        mean.append(np.mean(Matrix[i][1+j*24:25+j*24]))
    y = np.array(mean)

    A = np.vstack([x, np.ones(len(x))]).T
    m, c = np.linalg.lstsq(A, y)[0]
    
    '''
    plt.figure(figsize=(16,9))
        
    plt.plot(x,y)
    plt.plot(x, m*x + c, 'r', label='Fitted line')
    plt.ylabel("Temperature",fontsize=20)
    plt.xlabel("Year",fontsize=20)
    plt.savefig("./worldmap/images/"+Matrix[i][0]+".png")
    '''

    diff.append(m*(x[49] - x[0]))  
    #plt.show()


mean = np.mean(diff)
stdev = np.std(diff)

colorlist=['#0091DB','#0068B6','#0A308F','#005232','#009139','#6EB92B','#AACD03','#DADF00','#FAED00','#F1BC19','#E88121','#E03822','#B00015']

jsfile = open("./worldmap/mapdata.js","r").read()



count = 0
for i in range(CountryCount):
    tmp = np.abs((diff[i] - mean) / stdev)
    
    target = jsfile.find(Matrix[i][0])
    color  = jsfile.find("color:",target)
    #print target 
    if ( target != -1):
        count +=1
        for compare in range(12):
            if( tmp  >= 3.0 ):
                #print Matrix[i][0] + colorlist[12]
                jsfile = jsfile[0:color+8]+colorlist[12]+jsfile[color+15:] 
                print jsfile[color+7:color+16]
                break 
            if(tmp < 0.25*(compare+1)):
                #print Matrix[i][0] + colorlist[compare]
                jsfile = jsfile[0:color+8]+colorlist[compare]+jsfile[color+15:] 
                print jsfile[color+7:color+16]                
                break

newjs = open("./worldmap/newjs.js","w")
newjs.write(jsfile);
newjs.close()

        
f.close()
print count
print CountryCount
































